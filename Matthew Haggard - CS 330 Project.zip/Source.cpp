﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "shader.h"
#include <iostream>
#include "cylinder.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);

void drawCoffeCup(unsigned int texture, unsigned int vao, glm::mat4 model, Shader shader);
void drawCoffeeCupLid(unsigned int texture, unsigned int vao, glm::mat4 model, Shader shader);
void drawTable(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader);
void drawPyramid(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader);
void drawNotepad(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader);
void drawPen(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader);
void drawCoffeeCupLid2(unsigned int texture, unsigned int vao, glm::mat4 model, Shader shader);
void drawDonut(unsigned int texture, int vertices, unsigned int vao, unsigned int vbo, float angle, glm::mat4 model, Shader shader);
void drawPenTip(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader);


void setCoords(double r, double c, int rSeg, int cSeg, int i, int j, GLfloat* vertices, GLfloat* uv) {
	const double PI = 3.1415926535897932384626433832795;
	const double TAU = 2 * PI;

	double x = (c + r * cos(i * TAU / rSeg)) * cos(j * TAU / cSeg);
	double y = (c + r * cos(i * TAU / rSeg)) * sin(j * TAU / cSeg);
	double z = r * sin(i * TAU / rSeg);

	vertices[0] = 2 * x;
	vertices[1] = 2 * y;
	vertices[2] = 2 * z;

	uv[0] = i / (double)rSeg;
	uv[1] = j / (double)cSeg;
}

int createObject(double r, double c, int rSeg, int cSeg, GLfloat** vertices,
	GLfloat** uv) {
	int count = rSeg * cSeg * 6;
	*vertices = (GLfloat*)malloc(count * 3 * sizeof(GLfloat));
	*uv = (GLfloat*)malloc(count * 2 * sizeof(GLfloat));

	for (int x = 0; x < cSeg; x++) { // through stripes
		for (int y = 0; y < rSeg; y++) { // through squares on stripe
			GLfloat* vertexPtr = *vertices + ((x * rSeg) + y) * 18;
			GLfloat* uvPtr = *uv + ((x * rSeg) + y) * 12;
			setCoords(r, c, rSeg, cSeg, x, y, vertexPtr + 0, uvPtr + 0);
			setCoords(r, c, rSeg, cSeg, x + 1, y, vertexPtr + 3, uvPtr + 2);
			setCoords(r, c, rSeg, cSeg, x, y + 1, vertexPtr + 6, uvPtr + 4);

			setCoords(r, c, rSeg, cSeg, x, y + 1, vertexPtr + 9, uvPtr + 6);
			setCoords(r, c, rSeg, cSeg, x + 1, y, vertexPtr + 12, uvPtr + 8);
			setCoords(r, c, rSeg, cSeg, x + 1, y + 1, vertexPtr + 15,
				uvPtr + 10);
		}
	}

	return count;
}

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
glm::vec3 cameraVert = glm::vec3(1.0f, 0.0f, 0.0f);
float cameraSpeedModifer = 1.0;
std::string viewType = "perspective";


bool firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0 / 2.0;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Module 3 - Milestone", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader ourShader("shaderfiles/7.3.camera.vs", "shaderfiles/7.3.camera.fs");

	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------

	// Donuts
	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	// Projection matrix : 45� Field of View, 4:3 ratio, display range : 0.1 unit <-> 100 units
	glm::mat4 Projection = glm::perspective(45.0f, 4.0f / 3.0f, 0.1f, 100.0f);
	// Camera matrix
	glm::mat4 View = glm::lookAt(glm::vec3(0, -15, 12), // Camera is at (4,3,3), in World Space
		glm::vec3(0, 0, 0), // and looks at the origin
		glm::vec3(0, 1, 0)  // Head is up (set to 0,-1,0 to look upside-down)
	);
	// Model matrix : an identity matrix (model will be at the origin)
	glm::mat4 Model = glm::mat4(1.0f);


	// Our ModelViewProjection : multiplication of our 3 matrices
	glm::mat4 MVP = Projection * View * Model; // Remember, matrix multiplication is the other way around

	GLfloat* g_vertex_buffer_data;
	GLfloat* g_uv_buffer_data;
	int donutVertices = createObject(1, 1.5, 360, 360, &g_vertex_buffer_data, &g_uv_buffer_data);

	GLuint vertexbuffer;
	glGenBuffers(1, &vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, donutVertices * 3 * sizeof(GLfloat), g_vertex_buffer_data, GL_STATIC_DRAW);

	GLuint uvbuffer;
	glGenBuffers(1, &uvbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, uvbuffer);
	glBufferData(GL_ARRAY_BUFFER, donutVertices * 2 * sizeof(GLfloat), g_uv_buffer_data, GL_STATIC_DRAW);

	// Pyramid
	float vertices[] = {
		-0.5f, -0.5f, 0.5f,  0.0f, 0.0f, // base 01
		 0.5f, -0.5f, 0.5f,  1.0f, 0.0f,
		 0.5f,  0.5f, 0.5f,  1.0f, 1.0f,

		 0.5f,  0.5f, 0.5f,  1.0f, 1.0f, // base 02
		-0.5f,  0.5f, 0.5f,  0.0f, 1.0f,
		-0.5f, -0.5f, 0.5f,  0.0f, 0.0f,

		-0.5f, -0.5f, 0.5f,  0.0f, 0.0f, // Front
		 0.5f, -0.5f, 0.5f,  1.0f, 0.0f,
		 0.0f,  0.0f, -0.5f,  1.0f, 1.0f,

		-0.5f, 0.5f, 0.5f,  1.0f, 1.0f,// back
		 0.5f, 0.5f, 0.5f,  0.0f, 1.0f,
		 0.0f, 0.0f, -0.5f,  0.0f, 0.0f,

		 0.5f,  0.5f, 0.5f,  1.0f, 1.0f, // right
		 0.5f, -0.5f, 0.5f,  0.0f, 1.0f,
		 0.0f,  0.0f, -0.5f,  0.0f, 0.0f,

		 -0.5f,  0.5f, 0.5f,  1.0f, 1.0f, // left
		 -0.5f, -0.5f, 0.5f,  0.0f, 1.0f,
		 -0.0f,  0.0f,  -0.5f,  0.0f, 0.0f,
	};

	unsigned int VBO, VAO;

	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// texture coord attribute
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Plane 
	const float REPEAT = 1;
	const float OTHER_VAR = 0;

	float planeVertices[] = {
		-5.0f, -5.0f, -5.0f,  0.0f, 0.0f, // top 01
		 5.0f, -5.0f, -5.0f,  1.0f, 0.0f,
		 5.0f, -5.0f,  5.0f,  1.0f, 1.0f,

		 5.0f, -5.0f,  5.0f,  1.0f, 1.0f, // top 02
		-5.0f, -5.0f,  5.0f,  0.0f, 1.0f,
		-5.0f, -5.0f, -5.0f,  0.0f, 0.0f,

		-5.0f, -5.13f, -5.0f,  0.0f, 0.0f, // bottom 03
		 5.0f, -5.13f, -5.0f,  1.0f, 0.0f,
		 5.0f, -5.13f,  5.0f,  1.0f, 1.0f,

		 5.0f, -5.13f,  5.0f,  1.0f, 1.0f, // bottom 04
		-5.0f, -5.13f,  5.0f,  0.0f, 1.0f,
		-5.0f, -5.13f, -5.0f,  0.0f, 0.0f,

		-5.0f, -5.13f, -5.0f,  0.0f, 0.0f, // back 01
		-5.0f, -5.0f,  -5.0f,  1.0f, 0.0f,
		 5.0f, -5.0f,  -5.0f,  1.0f, 1.0f,

		 5.0f, -5.13f, -5.0f,  0.0f, 0.0f, // back 02
		 5.0f, -5.0f,  -5.0f,  1.0f, 0.0f,
		-5.0f, -5.13f, -5.0f,  1.0f, 1.0f,

		-5.0f, -5.13f, 5.0f,  0.0f, 0.0f, // front 01
		-5.0f, -5.0f,  5.0f,  1.0f, 0.0f,
		 5.0f, -5.0f,  5.0f,  1.0f, 1.0f,

		 5.0f, -5.13f, 5.0f,  0.0f, 0.0f, // front 02
		 5.0f, -5.0f,  5.0f,  1.0f, 0.0f,
		-5.0f, -5.13f, 5.0f,  1.0f, 1.0f,

		5.0f, -5.0f,  -5.0f,  1.0f, 1.0f, // right 01
		5.0f, -5.0f,   5.0f,  1.0f, 0.0f,
		5.0f, -5.13f, -5.0f,  0.0f, 0.0f,

		5.0f, -5.0f,   5.0f,  0.0f, 0.0f, // right 02
		5.0f, -5.13f,  5.0f,  1.0f, 0.0f,
		5.0f, -5.13f, -5.0f,  1.0f, 1.0f,

		-5.0f, -5.0f,  -5.0f, 1.0f, 1.0f, // left 01
		-5.0f, -5.0f,   5.0f, 1.0f, 0.0f,
		-5.0f, -5.13f, -5.0f, 0.0f, 0.0f,

		-5.0f, -5.0f,   5.0f,  1.0f, 1.0f, // left 02
		-5.0f, -5.13f,  5.0f,  1.0f, 0.0f,
		-5.0f, -5.13f, -5.0f,  0.0f, 0.0f,
	};

	unsigned int VBO4, VAO4; // Plane

	glGenVertexArrays(1, &VAO4);
	glGenBuffers(1, &VBO4);
	glBindVertexArray(VAO4);
	glBindBuffer(GL_ARRAY_BUFFER, VBO4);
	glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

	// position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// texture coord attribute
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// Coffee Cup
	unsigned int VBO2, VAO2;
	glGenVertexArrays(1, &VAO2);
	glGenBuffers(1, &VBO2);
	glBindVertexArray(VAO2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO2);

	// Coffee Cup Lid
	unsigned int VBO3, VAO3;
	glGenVertexArrays(1, &VAO3);
	glGenBuffers(1, &VBO3);
	glBindVertexArray(VAO3);
	glBindBuffer(GL_ARRAY_BUFFER, VBO3);

	// Pen


	// Notepad
	float notepadVerts01[] = {
		-5.0f, -5.0f, -5.0f,  0.0f, 0.0f, // base 01
		-2.5f, -5.0f, -5.0f,  1.0f, 0.0f,
		-5.0f, -5.0f, -1.25f,  1.0f, 1.0f,

		-5.0f, -5.0f, -1.25f,  1.0f, 1.0f, // base 02
		-2.5f, -5.0f, -1.25f,  0.0f, 1.0f,
		-2.5f, -5.0f, -5.0f,   0.0f, 0.0f
	};

	unsigned int VBO5, VAO5;

	glGenVertexArrays(1, &VAO5);
	glGenBuffers(1, &VBO5);
	glBindVertexArray(VAO5);
	glBindBuffer(GL_ARRAY_BUFFER, VBO5);
	glBufferData(GL_ARRAY_BUFFER, sizeof(notepadVerts01), notepadVerts01, GL_STATIC_DRAW);

	// position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// texture coord attribute
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	// PenTip
	unsigned int VBO6, VAO6;

	glGenVertexArrays(1, &VAO6);
	glGenBuffers(1, &VBO6);
	glBindVertexArray(VAO6);
	glBindBuffer(GL_ARRAY_BUFFER, VBO6);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// texture coord attribute
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	/* Setup Textures */

	// load and create a texture 
	unsigned int texture1, texture2, texture3, texture4, texture5, texture6, texture7;

	// texture 1
	glGenTextures(1, &texture1);
	glBindTexture(GL_TEXTURE_2D, texture1);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	// Texture 1: Table texture
	int width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char* data = stbi_load("images/table3.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// Texture 2: Cup texture
	glGenTextures(1, &texture2);
	glBindTexture(GL_TEXTURE_2D, texture2);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	data = stbi_load("images/cup.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		// note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// texture 3
	glGenTextures(1, &texture3);
	glBindTexture(GL_TEXTURE_2D, texture3);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	// Texture 3: Cup Lid
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	data = stbi_load("images/cuplid.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// Texture 4: Rocketbook texture
	glGenTextures(1, &texture4);
	glBindTexture(GL_TEXTURE_2D, texture4);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	data = stbi_load("images/paper2.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		// note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// Texture 5: Donut Texture
	glGenTextures(1, &texture5);
	glBindTexture(GL_TEXTURE_2D, texture5);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	data = stbi_load("images/donut.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		// note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// Texture 6: Pen Texture
	glGenTextures(1, &texture6);
	glBindTexture(GL_TEXTURE_2D, texture6);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	data = stbi_load("images/pencil.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		// note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// Texture 7: Pen tip Texture
	glGenTextures(1, &texture7);
	glBindTexture(GL_TEXTURE_2D, texture7);

	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// load image, create texture and generate mipmaps
	data = stbi_load("images/pencileraser.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		// note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	ourShader.use();
	ourShader.setInt("texture1", 0);
	ourShader.setInt("texture2", 1);
	ourShader.setInt("texture3", 2);
	ourShader.setInt("texture4", 3);

	glm::mat4 model;
	float angle;

	// render loop
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		processInput(window);

		// render
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// activate shader
		ourShader.use();

		// pass projection matrix to shader (note that in this case it could change every frame)
		glm::mat4 projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 50.0f);

		// Orthographic view
		glm::mat4 ortho = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, -10.0f, 10.0f);


		if (viewType == "perspective") {
			ourShader.setMat4("projection", projection);
		}

		else {
			ourShader.setMat4("projection", ortho);
		}

		// camera/view transformation
		glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
		ourShader.setMat4("view", view);

		// Draw Things
		angle = 0.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));

		// Draw the shapes for the scene
		drawTable(texture1, VAO4, angle, model, ourShader);
		drawCoffeCup(texture2, VAO2, model, ourShader);
		drawCoffeeCupLid(texture3, VAO3, model, ourShader);
		drawCoffeeCupLid2(texture3, VAO3, model, ourShader);
		drawNotepad(texture4, VAO5, angle, model, ourShader);
		drawPen(texture6, VAO2, 90.0, model, ourShader);
		drawDonut(texture5, donutVertices, vertexbuffer, uvbuffer, angle, model, ourShader);
		//drawPyramid(texture7, VAO, angle, model, ourShader);
		drawPenTip(texture7, VAO2, 90.0, model, ourShader);

		MVP = Projection * View * Model;
		// Send our transformation to the currently bound shader,
		// in the "MVP" uniform

		// Set our "myTextureSampler" sampler to user Texture Unit 0
		//glUniform1i(TextureID, 0);




		// Print camera speed to the console
		std::cout << "CAMERA SPEED: " << cameraSpeedModifer << std::endl;

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);

	glDeleteVertexArrays(1, &VAO2);
	glDeleteBuffers(1, &VBO2);

	glDeleteVertexArrays(1, &VAO3);
	glDeleteBuffers(1, &VBO3);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraSpeed = 2.5 * deltaTime * cameraSpeedModifer;

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;

	// Vertical movement with the q and e key on the keyboard
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraVert)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraVert)) * cameraSpeed;

	// Change perspective
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
		if (viewType == "perspective") {
			viewType = "ortho";
		}

		else if (viewType == "ortho") {
			viewType = "perspective";
		}
	}
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}
	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	float sensitivity = 0.1f; // change this value to your liking
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// make sure that when pitch is out of bounds, screen doesn't get flipped
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	/*
	fov -= (float)yoffset;
	if (fov < 1.0f)
		fov = 1.0f;
	if (fov > 45.0f)
		fov = 45.0f;
	*/


	if (yoffset < 0) {
		std::cout << "You are scrolling down";
		cameraSpeedModifer -= 1;
		if (cameraSpeedModifer < 1) {
			cameraSpeedModifer = 1;
		}
	}

	if (yoffset > 0) {
		std::cout << "You are scrolling up";
		cameraSpeedModifer += 1;
	}
}

void drawCoffeCup(unsigned int texture, unsigned int vao, glm::mat4 model, Shader shader) {
	// This draws the cylinder for the coffee cup
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(0.0f, -1.5f, 0.0f));
	shader.setMat4("model", model);

	static_meshes_3D::Cylinder cup(0.75, 50, 2, true, true, true);
	cup.render();
}

void drawCoffeeCupLid(unsigned int texture, unsigned int vao, glm::mat4 model, Shader shader) {
	// This draws the cylinder for the coffee cup lid
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(0.0f, -0.5f, 0.0f));
	shader.setMat4("model", model);

	static_meshes_3D::Cylinder lid(0.80, 50, 0.15, true, true, true);
	lid.render();
}
void drawCoffeeCupLid2(unsigned int texture, unsigned int vao, glm::mat4 model, Shader shader) {
	// This draws the cylinder for the coffee cup lid
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);
	float angle = -10.0f;

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(0.0f, -0.51f, 0.07f));
	model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
	model = glm::scale(model, glm::vec3(0.9f, 0.9f, 0.9f));
	shader.setMat4("model", model);

	static_meshes_3D::Cylinder lid(0.80, 50, 0.15, true, true, true);
	lid.render();
}

void drawTable(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader) {
	// Below are the settings for the plane.
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(2.75f, 2.49f, 1.0f));
	model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.0f, 0.0f));
	shader.setMat4("model", model);

	glDrawArrays(GL_TRIANGLES, 0, 36);
}

void drawPyramid(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader) {
	// Below are the settings for the pyramid.
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
	model = glm::translate(model, glm::vec3(3.95, -2.4, 3.4));
	angle = 0;
	model = glm::rotate(model, glm::radians(angle), glm::vec3(0.75f, 1.0f, 0.5f));
	model = glm::scale(model, glm::vec3(0.15f, 0.15f, 0.15f));
	shader.setMat4("model", model);

	glDrawArrays(GL_TRIANGLES, 0, 36);
}

void drawNotepad(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader) {
	// Below are the settings for the plane.
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(8.0f, 2.5f, 7.0f));
	model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
	shader.setMat4("model", model);

	glDrawArrays(GL_TRIANGLES, 0, 6);
}

void drawPen(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader) {
	// This draws the cylinder for the coffee cup lid
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(4.5f, -2.40f, 4.0f));
	model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.0f, -1.0f));
	shader.setMat4("model", model);

	static_meshes_3D::Cylinder lid(0.08, 8, 1.6, true, true, true);
	lid.render();
}

void drawPenTip(unsigned int texture, unsigned int vao, float angle, glm::mat4 model, Shader shader) {
	// This draws the cylinder for the coffee cup lid
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
	model = glm::translate(model, glm::vec3(4.12f, -2.40f, 3.62f));
	model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.0f, -1.0f));
	shader.setMat4("model", model);

	static_meshes_3D::Cylinder lid(0.07, 50, 0.8, true, true, true);
	lid.render();
}

void drawDonut(unsigned int texture, int vertices, unsigned int vao, unsigned int vbo, float angle, glm::mat4 model, Shader shader) {
	// Below are the settings for the pyramid.
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(vao);

	model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
	model = glm::translate(model, glm::vec3(3.0f, -2.30f, 0.0f));
	angle = 0.0f;
	model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
	model = glm::scale(model, glm::vec3(0.05f, 0.05f, 0.05f));
	shader.setMat4("model", model);

	// 1rst attribute buffer : vertices
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vao);
	glVertexAttribPointer(0, // attribute. No particular reason for 0, but must match the layout in the shader.
		3,                  // size
		GL_FLOAT,           // type
		GL_FALSE,           // normalized?
		0,                  // stride
		(void*)0            // array buffer offset
	);

	// 2nd attribute buffer : UVs
	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glVertexAttribPointer(1, // attribute. No particular reason for 1, but must match the layout in the shader.
		2,                                // size : U+V => 2
		GL_FLOAT,                         // type
		GL_FALSE,                         // normalized?
		0,                                // stride
		(void*)0                          // array buffer offset
	);

	glFrontFace(GL_CW);

	// Draw the triangle !
	glDrawArrays(GL_TRIANGLES, 0, vertices * 3); // 12*3 indices starting at 0 -> 12 triangles

	glFrontFace(GL_CCW);
}
